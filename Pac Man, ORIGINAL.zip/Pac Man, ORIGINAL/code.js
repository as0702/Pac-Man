var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["beb934cf-413d-452c-b16c-3f224e988882","e739a029-46bc-4510-bcf2-39c0c440a823","a30d75fc-91fd-4245-a2a2-bf54857be05b","95e992d3-cbe5-4405-97ae-20fe924d52cb","9366d97a-7ff7-45dc-8566-211a60fb2d5f","52990e6f-c153-459c-926e-1c6b05fd875a","5db33e45-ed9e-4b5c-bf41-8e787c9dbd90","25df55f0-50f2-48ba-9aa0-31ce7da2fb2b","ca581fef-e756-44ed-b5a9-640006133f0f","fa744b01-c07b-4092-ab19-0b463e08a7c7","5992c939-4e59-43db-87ad-f1f1287302bb","ee15966c-561c-4365-8308-0d6a8446e92f","63887bc9-f4f2-4372-b789-f4170cfbf1e3","22268f3a-1131-403f-a651-54a9d1477f3e","93d562ac-2aaf-4969-a331-4f819f833078","d0b1fbc5-1483-4495-9084-e2c97dff52ef","e4582374-6cc3-4a62-b1d1-55b1e6805cf6","11aeb12f-2500-410e-b769-54b9f9437b84","3666f8df-338d-4ee9-8025-243921de3bcc","91351110-d069-4037-a927-5f4477999531","7fee578c-e2a3-4619-a774-89584b7e20d0","04001581-75d5-4ff8-933f-633b47203170","81335bf1-2551-42a7-af1d-9a78e08bf438","52665e3b-ce7b-4262-b68c-594f80a56a46","7258704d-03e6-4295-8bdd-bc60efe8a6c8","983d3e5b-1b43-489b-bc9f-b6f4550a8759","7fef4508-ffcf-4f72-93e6-b69da0c957a6","12759484-de11-4f11-9445-ccf325acc13b","7665dd13-0aed-4f23-a520-f1668f5e0885","3ae753f4-e236-44ec-8763-c3db43db2d22","3a3de97a-2487-4c07-a6bf-1e2b6421d29f","0342ae2c-85dc-4ed8-875c-cc62db9403bd","856d6e48-f4b0-4c75-8ee8-f07aafc1f4ee","021b3ccb-8930-42c3-bba4-10d3a22c287c","1bfa19ba-7278-4c57-80d0-f7deae05ada4","1ef6bf75-c546-4731-8a81-9d3b491754f5","d6a7d54e-d02d-4702-90aa-50038e2d7aa2","015f4913-60d2-45d5-994b-55e709b29ad9","596906c5-8b83-49d3-b767-a520c03b69ae","082251d2-1a9d-4395-b41f-27aa385eb763","1ef91305-59ee-4e0b-b6b7-73e569c4bcdd","60ce5d9c-8668-477a-a499-4743d72f335a","c8d6ad5d-797f-4ef7-ac6a-4e4f2c17fbca","f444a948-afdc-4916-98bc-af4353cda4fa","30e4ea21-fdab-4aa0-a036-2edbb43edeb8","53a6cb47-5fd2-4d8a-8e9f-b145fc1acd4d"],"propsByKey":{"beb934cf-413d-452c-b16c-3f224e988882":{"name":"R_Pac","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":2,"looping":true,"frameDelay":2,"version":"CS_bougq53GwLFBMrzDoefN1X0X8DTy_","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":200},"rootRelativePath":"assets/beb934cf-413d-452c-b16c-3f224e988882.png"},"e739a029-46bc-4510-bcf2-39c0c440a823":{"name":"U_Pac","sourceUrl":null,"frameSize":{"x":96,"y":96},"frameCount":2,"looping":true,"frameDelay":2,"version":"3HTNI5oZa4vvB2k.TnCedh6RCDOwxNgC","loadedFromSource":true,"saved":true,"sourceSize":{"x":96,"y":192},"rootRelativePath":"assets/e739a029-46bc-4510-bcf2-39c0c440a823.png"},"a30d75fc-91fd-4245-a2a2-bf54857be05b":{"name":"death","sourceUrl":null,"frameSize":{"x":96,"y":96},"frameCount":18,"looping":true,"frameDelay":2,"version":"7FruB91qsxub1fC48g1AjEt02hHy1xJN","loadedFromSource":true,"saved":true,"sourceSize":{"x":384,"y":480},"rootRelativePath":"assets/a30d75fc-91fd-4245-a2a2-bf54857be05b.png"},"95e992d3-cbe5-4405-97ae-20fe924d52cb":{"name":"L_Pac","sourceUrl":null,"frameSize":{"x":96,"y":96},"frameCount":2,"looping":true,"frameDelay":2,"version":"u4dFdA1QzbsGpp65JdBywP9u9zpwQfG7","loadedFromSource":true,"saved":true,"sourceSize":{"x":96,"y":192},"rootRelativePath":"assets/95e992d3-cbe5-4405-97ae-20fe924d52cb.png"},"9366d97a-7ff7-45dc-8566-211a60fb2d5f":{"name":"stationary_Pac","sourceUrl":null,"frameSize":{"x":96,"y":96},"frameCount":1,"looping":true,"frameDelay":12,"version":"Z7CkCCaaRy7scWLqyK6FtkRYHvFTW2gg","loadedFromSource":true,"saved":true,"sourceSize":{"x":96,"y":96},"rootRelativePath":"assets/9366d97a-7ff7-45dc-8566-211a60fb2d5f.png"},"52990e6f-c153-459c-926e-1c6b05fd875a":{"name":"D_Pac","sourceUrl":null,"frameSize":{"x":96,"y":96},"frameCount":2,"looping":true,"frameDelay":2,"version":"Y9F58hkEo7hMqhT1HV_8blLsedAC8moq","loadedFromSource":true,"saved":true,"sourceSize":{"x":96,"y":192},"rootRelativePath":"assets/52990e6f-c153-459c-926e-1c6b05fd875a.png"},"5db33e45-ed9e-4b5c-bf41-8e787c9dbd90":{"name":"L_Blinky","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"oVvGjwjrUmmHy42vF7gdVtAb6tf7V9bs","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/5db33e45-ed9e-4b5c-bf41-8e787c9dbd90.png"},"25df55f0-50f2-48ba-9aa0-31ce7da2fb2b":{"name":"L_Clyde","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"SPFD8t74hHqpqNfuY7eY.AAVT66.RfFX","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/25df55f0-50f2-48ba-9aa0-31ce7da2fb2b.png"},"ca581fef-e756-44ed-b5a9-640006133f0f":{"name":"L_Inky","sourceUrl":null,"frameSize":{"x":96,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"BAy4QmdkQaWzRlwAI9UJpMQhtNuHq7Yx","loadedFromSource":true,"saved":true,"sourceSize":{"x":96,"y":180},"rootRelativePath":"assets/ca581fef-e756-44ed-b5a9-640006133f0f.png"},"fa744b01-c07b-4092-ab19-0b463e08a7c7":{"name":"L_Pinky","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"uav9Xl39N1CVPZHVbRI8fPX5vMKUkDvu","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/fa744b01-c07b-4092-ab19-0b463e08a7c7.png"},"5992c939-4e59-43db-87ad-f1f1287302bb":{"name":"R_Blinky","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"FpLQpPvGOjFa4qB49IdOFnxiZhwgOP5z","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/5992c939-4e59-43db-87ad-f1f1287302bb.png"},"ee15966c-561c-4365-8308-0d6a8446e92f":{"name":"R_Clyde","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"Gdang8t7S543mKX3Ha6r5A4zuaRqrKBq","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/ee15966c-561c-4365-8308-0d6a8446e92f.png"},"63887bc9-f4f2-4372-b789-f4170cfbf1e3":{"name":"R_Inky","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"xjpTmxQDx7U9dr7q41RrA9VW.4jMnX_e","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/63887bc9-f4f2-4372-b789-f4170cfbf1e3.png"},"22268f3a-1131-403f-a651-54a9d1477f3e":{"name":"R_Pinky","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"p6yT2MlgNyYwxMln0Rfuur.OFJvyZM0f","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/22268f3a-1131-403f-a651-54a9d1477f3e.png"},"93d562ac-2aaf-4969-a331-4f819f833078":{"name":"U_Blinky","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"wqs5AhBHE7CLSUe2jpx50FyInd97lYcH","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/93d562ac-2aaf-4969-a331-4f819f833078.png"},"d0b1fbc5-1483-4495-9084-e2c97dff52ef":{"name":"U_Clyde","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"UNkLJItDL_kkKI6IDcefjqlvZNDKauXx","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/d0b1fbc5-1483-4495-9084-e2c97dff52ef.png"},"e4582374-6cc3-4a62-b1d1-55b1e6805cf6":{"name":"U_Inky","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"nSORFMo25l83wmAnOpD5ehlUIp4NXcqN","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/e4582374-6cc3-4a62-b1d1-55b1e6805cf6.png"},"11aeb12f-2500-410e-b769-54b9f9437b84":{"name":"U_Pinky","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"yA6U2sS_BmS2IdKJO3oeZb_F.oUPF2rg","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/11aeb12f-2500-410e-b769-54b9f9437b84.png"},"3666f8df-338d-4ee9-8025-243921de3bcc":{"name":"D_Blinky","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"X4yiSnqBy1.TP_CBq6Afvrvzz8hNFDZj","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/3666f8df-338d-4ee9-8025-243921de3bcc.png"},"91351110-d069-4037-a927-5f4477999531":{"name":"D_Clyde","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"MgyBZZFJ9ExcW3KWIQFQcRlcfZtfKYF4","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/91351110-d069-4037-a927-5f4477999531.png"},"7fee578c-e2a3-4619-a774-89584b7e20d0":{"name":"D_Inky","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"8OdU7wE6rVXo0ptrbUsMs9939d5RuNli","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/7fee578c-e2a3-4619-a774-89584b7e20d0.png"},"04001581-75d5-4ff8-933f-633b47203170":{"name":"D_Pinky","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"fCNtUiXYV4l.ZdWPTdqKsXfiGILTx0es","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/04001581-75d5-4ff8-933f-633b47203170.png"},"81335bf1-2551-42a7-af1d-9a78e08bf438":{"name":"Blue","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"3sowGlapmTw7Ko628b9UbfTz3nmYhDNU","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/81335bf1-2551-42a7-af1d-9a78e08bf438.png"},"52665e3b-ce7b-4262-b68c-594f80a56a46":{"name":"Blue_Dead","sourceUrl":null,"frameSize":{"x":94,"y":90},"frameCount":2,"looping":true,"frameDelay":12,"version":"IdJPqfMZaMCavPbx_lNV.8PN56pfoiHq","loadedFromSource":true,"saved":true,"sourceSize":{"x":94,"y":180},"rootRelativePath":"assets/52665e3b-ce7b-4262-b68c-594f80a56a46.png"},"7258704d-03e6-4295-8bdd-bc60efe8a6c8":{"name":"Cherry","sourceUrl":null,"frameSize":{"x":73,"y":79},"frameCount":1,"looping":true,"frameDelay":12,"version":"Xk_1X5D3j0elxqcnrqCK3eHszXRynEda","loadedFromSource":true,"saved":true,"sourceSize":{"x":73,"y":79},"rootRelativePath":"assets/7258704d-03e6-4295-8bdd-bc60efe8a6c8.png"},"983d3e5b-1b43-489b-bc9f-b6f4550a8759":{"name":"border","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"fEP44RSuOgeICza8MuZzdVAxSOWDerET","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/983d3e5b-1b43-489b-bc9f-b6f4550a8759.png"},"7fef4508-ffcf-4f72-93e6-b69da0c957a6":{"name":"white","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"viU_NO.6TUgvF.85tbQkt.cbbiT.TuAa","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/7fef4508-ffcf-4f72-93e6-b69da0c957a6.png"},"12759484-de11-4f11-9445-ccf325acc13b":{"name":"black","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"aIVXGtyiSEJsxQZuD9Dv.fTbI1ecRVHc","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/12759484-de11-4f11-9445-ccf325acc13b.png"},"7665dd13-0aed-4f23-a520-f1668f5e0885":{"name":"Any","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"yc3CN4ne3WLR_dvIQSfWXR4i_S6c5sAl","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/7665dd13-0aed-4f23-a520-f1668f5e0885.png"},"3ae753f4-e236-44ec-8763-c3db43db2d22":{"name":"UR","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"fK6aPU4tcEGZ7hCzPijA.fkjOwJsd8Af","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/3ae753f4-e236-44ec-8763-c3db43db2d22.png"},"3a3de97a-2487-4c07-a6bf-1e2b6421d29f":{"name":"DR","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"cjkAuf88Kb8RIYjuCKQYHuKsI3fo73Ox","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/3a3de97a-2487-4c07-a6bf-1e2b6421d29f.png"},"0342ae2c-85dc-4ed8-875c-cc62db9403bd":{"name":"UL","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"nBtB3IHDNz7i_819lPLEOxbq9mWG0h_J","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/0342ae2c-85dc-4ed8-875c-cc62db9403bd.png"},"856d6e48-f4b0-4c75-8ee8-f07aafc1f4ee":{"name":"DL","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"BZB1pd0sAvQ6GAMDkLpAr4Xbb44NX8Xu","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/856d6e48-f4b0-4c75-8ee8-f07aafc1f4ee.png"},"021b3ccb-8930-42c3-bba4-10d3a22c287c":{"name":"RT","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"PZfBxguNybSaTY6m8H7xagelT2aqgrI.","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/021b3ccb-8930-42c3-bba4-10d3a22c287c.png"},"1bfa19ba-7278-4c57-80d0-f7deae05ada4":{"name":"UT","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"BKyG.M8iu8E6yikmnoHu6TMzXkZnVpCH","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/1bfa19ba-7278-4c57-80d0-f7deae05ada4.png"},"1ef6bf75-c546-4731-8a81-9d3b491754f5":{"name":"DT","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"P8mPB7895aTSIEohJdBeZaO.O7YVp8RN","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/1ef6bf75-c546-4731-8a81-9d3b491754f5.png"},"d6a7d54e-d02d-4702-90aa-50038e2d7aa2":{"name":"LT","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"ujh_D0BVV3QYv4oFqXAm69bRHebb9QBB","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/d6a7d54e-d02d-4702-90aa-50038e2d7aa2.png"},"015f4913-60d2-45d5-994b-55e709b29ad9":{"name":"U","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"_xc_s57lUdXVjsPr9xSIDqC6ZxeHYdjm","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/015f4913-60d2-45d5-994b-55e709b29ad9.png"},"596906c5-8b83-49d3-b767-a520c03b69ae":{"name":"animation_2","sourceUrl":"assets/api/v1/animation-library/mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz/category_backgrounds/blank.png","frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":4,"version":"mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/api/v1/animation-library/mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz/category_backgrounds/blank.png"},"082251d2-1a9d-4395-b41f-27aa385eb763":{"name":"strawberry","sourceUrl":null,"frameSize":{"x":89,"y":92},"frameCount":1,"looping":true,"frameDelay":12,"version":"GCtwwao.lcRIMyTA70PeaBZGeSoQoU7L","loadedFromSource":true,"saved":true,"sourceSize":{"x":89,"y":92},"rootRelativePath":"assets/082251d2-1a9d-4395-b41f-27aa385eb763.png"},"1ef91305-59ee-4e0b-b6b7-73e569c4bcdd":{"name":"orange","sourceUrl":null,"frameSize":{"x":93,"y":93},"frameCount":1,"looping":true,"frameDelay":12,"version":"O5sYuITvKJ2VzaGxXneuaBJc1BgKC9FV","loadedFromSource":true,"saved":true,"sourceSize":{"x":93,"y":93},"rootRelativePath":"assets/1ef91305-59ee-4e0b-b6b7-73e569c4bcdd.png"},"60ce5d9c-8668-477a-a499-4743d72f335a":{"name":"apple","sourceUrl":null,"frameSize":{"x":90,"y":89},"frameCount":1,"looping":true,"frameDelay":12,"version":"jfFG1ZiuH_KlAegajyCWeY8V._06ReDr","loadedFromSource":true,"saved":true,"sourceSize":{"x":90,"y":89},"rootRelativePath":"assets/60ce5d9c-8668-477a-a499-4743d72f335a.png"},"c8d6ad5d-797f-4ef7-ac6a-4e4f2c17fbca":{"name":"melon","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"BK2uwY1lRMHgq.xMcWaBETev89aKu13t","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/c8d6ad5d-797f-4ef7-ac6a-4e4f2c17fbca.png"},"f444a948-afdc-4916-98bc-af4353cda4fa":{"name":"circle","sourceUrl":null,"frameSize":{"x":91,"y":91},"frameCount":2,"looping":true,"frameDelay":12,"version":"EeP7QTL4QukOukCv40Li8HEWq0k_uRKH","loadedFromSource":true,"saved":true,"sourceSize":{"x":91,"y":182},"rootRelativePath":"assets/f444a948-afdc-4916-98bc-af4353cda4fa.png"},"30e4ea21-fdab-4aa0-a036-2edbb43edeb8":{"name":"yellow","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"upk3Vh7eREbwARcrQj0mVD4MaNOiPhbT","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/30e4ea21-fdab-4aa0-a036-2edbb43edeb8.png"},"53a6cb47-5fd2-4d8a-8e9f-b145fc1acd4d":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"UhavcUISYwpSprsjP_bnG7b0q5BMbYTv","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/53a6cb47-5fd2-4d8a-8e9f-b145fc1acd4d.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var color = prompt("What do you want the background of this Pac Man game to be");
var big = 100;
showMobileControls(true, true, true, true);
camera.zoom = 1;
camera.on();
noFill();
noStroke();
textFont(big);
var Borders = createGroup();
  var border1 = createSprite(200,360);
  border1.setAnimation("border");
  border1.height = 5;
  border1.width = 350;
  var border2 = createSprite(200,20);
  border2.setAnimation("border");
  border2.height = 5;
  border2.width = 350;
  var border3 = createSprite(28,73);
  border3.setAnimation("border");
  border3.height = 110;
  border3.width = 5;
  var border4 = createSprite(28,293);
  border4.setAnimation("border");
  border4.height = 131;
  border4.width = 5;
  var border5 = createSprite(65,127);
  border5.setAnimation("border");
  border5.height = 5;
  border5.width = 80;
  var border6 = createSprite(65,230);
  border6.setAnimation("border");
  border6.height = 5;
  border6.width = 80;
  var border7 = createSprite(105,214);
  border7.setAnimation("border");
  border7.height = 38;
  border7.width = 5;
  var border8 = createSprite(105,144);
  border8.setAnimation("border");
  border8.height = 38;
  border8.width = 5;
  var border9 = createSprite(42,196);
  border9.setAnimation("border");
  border9.height = 5;
  border9.width = 130;
  var border10 = createSprite(42,165);
  border10.setAnimation("border");
  border10.height = 5;
  border10.width = 130;
  var border11 = createSprite(373,73);
  border11.setAnimation("border");
  border11.height = 110;
  border11.width = 5;
  var border12 = createSprite(373,293);
  border12.setAnimation("border");
  border12.height = 131;
  border12.width = 5;
for (var i = 0; i < big; i++) {
  console.log(big + i);
  textFont("Courier New");
  textSize(20);
  noStroke();
  strokeWeight(Math.cos(big + i));
}
  var border13 = createSprite(335,127);
  border13.setAnimation("border");
  border13.height = 5;
  border13.width = 80;
  var border14 = createSprite(335,230);
  border14.setAnimation("border");
  border14.height = 5;
  border14.width = 80;
  var border15 = createSprite(295,214);
  border15.setAnimation("border");
  border15.width = 5;
  border15.height = 38;
  var border16 = createSprite(295,144);
  border16.setAnimation("border");
  border16.width = 5;
  border16.height = 38;
  var border17 = createSprite(357,196);
  border17.setAnimation("border");
  border17.width = 130;
  border17.height = 5;
  var border18 = createSprite(357,165);
  border18.setAnimation("border");
  border18.width = 130;
  border18.height = 5;
  var border19 = createSprite(200,205);
  border19.setAnimation("border");
  border19.height = 5;
  border19.width = 60;
  var border20 = createSprite(170,178);
  border20.setAnimation("border");
  border20.height = 60;
  border20.width = 5;
  var border21 = createSprite(230,178);
  border21.setAnimation("border");
  border21.height = 60;
  border21.width = 5;
  var border22 = createSprite(223,150);
  border22.setAnimation("border");
  border22.height = 5;
  border22.width = 17.5;
  var border23 = createSprite(177,150);
  border23.setAnimation("border");
  border23.height = 5;
  border23.width = 17.5;
  var border24 = createSprite(201,150);
  border24.setAnimation("white");
  border24.height = 2.5;
  border24.width = 27;
  var border25 = createSprite(45,296);
  border25.setAnimation("border");
  border25.height = 5;
  border25.width = 35;
  var border26 = createSprite(355,296);
  border26.setAnimation("border");
  border26.height = 5;
  border26.width = 35;
  var border27 = createSprite(105,281);
  border27.setAnimation("border");
  border27.width = 5;
  border27.height = 35;
  var border28 = createSprite(295,281);
  border28.setAnimation("border");
  border28.width = 5;
  border28.height = 35;
  var border29 = createSprite(90,262);
  border29.setAnimation("border");
  border29.height = 5;
  border29.width = 35;
  var border30 = createSprite(310,262);
  border30.setAnimation("border");
  border30.height = 5;
  border30.width = 35;
  var border31 = createSprite(115,328);
  border31.setAnimation("border");
  border31.height = 5;
  border31.width = 105;
  var border32 = createSprite(285,328);
  border32.setAnimation("border");
  border32.height = 5;
  border32.width = 105;
  var border33 = createSprite(140,313);
  border33.setAnimation("border");
  border33.width = 5;
  border33.height = 35;
  var border34 = createSprite(260,313);
  border34.setAnimation("border");
  border34.width = 5;
  border34.height = 35;
  var border35 = createSprite(200,313);
  border35.setAnimation("border");
  border35.width = 5;
  border35.height = 35;
  var border36 = createSprite(200,298);
  border36.setAnimation("border");
  border36.height = 5;
  border36.width = 59;
  var border37 = createSprite(200,255);
  border37.setAnimation("border");
  border37.width = 5;
  border37.height = 35;
  var border38 = createSprite(200,240);
  border38.setAnimation("border");
  border38.height = 5;
  border38.width = 66;
  var border39 = createSprite(154,270);
  border39.setAnimation("border");
  border39.height = 5;
  border39.width = 35;
  var border40 = createSprite(246,270);
  border40.setAnimation("border");
  border40.height = 5;
  border40.width = 35;
  var border41 = createSprite(137,218);
  border41.setAnimation("border");
  border41.width = 5;
  border41.height = 50;
  var border42 = createSprite(263,218);
  border42.setAnimation("border");
  border42.width = 5;
  border42.height = 50;
  var border43 = createSprite(263,130.5);
  border43.setAnimation("border");
  border43.height = 75;
  border43.width = 5;
  var border44 = createSprite(245.5,122);
  border44.setAnimation("border");
  border44.width = 35;
  border44.height = 5;
  var border45 = createSprite(154.5,122);
  border45.setAnimation("border");
  border45.width = 35;
  border45.height = 5;
  var border46 = createSprite(137,130.5);
  border46.setAnimation("border");
  border46.height = 75;
  border46.width = 5;
  var border47 = createSprite(200,88);
  border47.setAnimation("border");
  border47.width = 70;
  border47.height = 5;
  var border48 = createSprite(200,103);
  border48.setAnimation("border");
  border48.width = 5;
  border48.height = 35;
  var border49 = createSprite(200,35);
  border49.setAnimation("border");
  border49.width = 5;
  border49.height = 35;
  var border50 = createSprite(84.5,95);
  border50.setAnimation("border");
  border50.height = 5;
  border50.width = 48;
  var border51 = createSprite(316.5,95);
  border51.setAnimation("border");
  border51.height = 5;
  border51.width = 48;
  var border52 = createSprite(316.5,65);
  border52.setAnimation("border");
  border52.width = 48;
  border52.height = 5;
  var border53 = createSprite(316.5, 50);
  border53.setAnimation("border");
  border53.width = 48;
  border53.height = 5;
  var border54 = createSprite(295,58.5);
  border54.setAnimation("border");
  border54.width = 5;
  border54.height = 15;
  var border55 = createSprite(338,58.5);
  border55.setAnimation("border");
  border55.width = 5;
  border55.height = 15;
  var border56 = createSprite(246.5,59);
  border56.setAnimation("border");
  border56.width = 35;
  border56.height = 5;
  var border57 = createSprite(246.5, 44);
  border57.setAnimation("border");
  border57.width = 35;
  border57.height = 5;
  var border58 = createSprite(232,52.5);
  border58.setAnimation("border");
  border58.width = 5;
  border58.height = 15;
  var border59 = createSprite(262,52.5);
  border59.setAnimation("border");
  border59.width = 5;
  border59.height = 15;
  var border60 = createSprite(83.5,65);
  border60.setAnimation("border");
  border60.width = 48;
  border60.height = 5;
  var border61 = createSprite(83.5, 50);
  border61.setAnimation("border");
  border61.width = 48;
  border61.height = 5;
  var border62 = createSprite(105,58.5);
  border62.setAnimation("border");
  border62.width = 5;
  border62.height = 15;
  var border63 = createSprite(62,58.5);
  border63.setAnimation("border");
  border63.width = 5;
  border63.height = 15;
  var border64 = createSprite(153.5,59);
  border64.setAnimation("border");
  border64.width = 35;
  border64.height = 5;
  var border65 = createSprite(153.5, 44);
  border65.setAnimation("border");
  border65.width = 35;
  border65.height = 5;
  var border66 = createSprite(169,52.5);
  border66.setAnimation("border");
  border66.width = 5;
  border66.height = 15;
  var border67 = createSprite(139,52.5);
  border67.setAnimation("border");
  border67.width = 5;
  border67.height = 15;
  Borders.add(border1);
  Borders.add(border2);
  Borders.add(border3);
  Borders.add(border4);
  Borders.add(border5);
  Borders.add(border6);
  Borders.add(border7);
  Borders.add(border8);
  Borders.add(border9);
  Borders.add(border10);
  Borders.add(border11);
  Borders.add(border12);
  Borders.add(border13);
  Borders.add(border14);
  Borders.add(border15);
  Borders.add(border16);
  Borders.add(border17);
  Borders.add(border18);
  Borders.add(border19);
  Borders.add(border20);
  Borders.add(border21);
  Borders.add(border22);
  Borders.add(border23);
  Borders.add(border25);
  Borders.add(border26);
  Borders.add(border27);
  Borders.add(border28);
  Borders.add(border29);
  Borders.add(border30);
  Borders.add(border31);
  Borders.add(border32);
  Borders.add(border33);
  Borders.add(border34);
  Borders.add(border35);
  Borders.add(border36);
  Borders.add(border37);
  Borders.add(border38);
  Borders.add(border39);
  Borders.add(border40);
  Borders.add(border41);
  Borders.add(border42);
  Borders.add(border43);
  Borders.add(border44);
  Borders.add(border45);
  Borders.add(border46);
  Borders.add(border47);
  Borders.add(border48);
  Borders.add(border49);
  Borders.add(border50);
  Borders.add(border51);
  Borders.add(border52);
  Borders.add(border53);
  Borders.add(border54);
  Borders.add(border55);
  Borders.add(border56);
  Borders.add(border57);
  Borders.add(border58);
  Borders.add(border59);
  Borders.add(border60);
  Borders.add(border61);
  Borders.add(border62);
  Borders.add(border63);
  Borders.add(border64);
  Borders.add(border65);
  Borders.add(border66);
  Borders.add(border67);
  var promptAny = createGroup();
  var promptUR = createGroup();
  var promptDR = createGroup();
  var promptUL = createGroup();
  var promptDL = createGroup();
  var promptUT = createGroup();
  var promptDT = createGroup();
  var promptRT = createGroup();
  var promptLT = createGroup();
  var promptU = createGroup();
  var ghostblock1 = createSprite(45,35);
  var ghostblock2 = createSprite(122,32);
  var ghostblock3 = createSprite(280,32);
  var ghostblock4 = createSprite(355,35);
  var ghostblock5 = createSprite(185,32);
  var ghostblock6 = createSprite(215,32);
  var ghostblock7 = createSprite(45,82);
  var ghostblock8 = createSprite(122,78);
  var ghostblock9 = createSprite(150,73);
  var ghostblock10 = createSprite(185,72);
  var ghostblock11 = createSprite(215,72);
  var ghostblock12 = createSprite(280,78);
  var ghostblock13 = createSprite(355,82);
  var ghostblock14 = createSprite(250,73);
  var ghostblock15 = createSprite(45,112);
  var ghostblock16 = createSprite(122,112);
  var ghostblock17 = createSprite(152,108);
  var ghostblock18 = createSprite(183,108);
  var ghostblock19 = createSprite(217,108);
  var ghostblock20 = createSprite(247,108);
  var ghostblock21 = createSprite(280,112);
  var ghostblock22 = createSprite(355,112);
  var ghostblock23 = createSprite(122,180);
  var ghostblock24 = createSprite(155,180);
  var ghostblock25 = createSprite(153,137);
  var ghostblock26 = createSprite(185,135);
  var ghostblock27 = createSprite(280,180);
  var ghostblock28 = createSprite(245,180);
  var ghostblock29 = createSprite(247,137);
  var ghostblock30 = createSprite(215,135);
  var ghostblock31 = createSprite(120,251);
  var ghostblock32 = createSprite(50,249);
  var ghostblock33 = createSprite(152,255);
  var ghostblock34 = createSprite(155,225);
  var ghostblock35 = createSprite(280,249);
  var ghostblock36 = createSprite(350,249);
  var ghostblock37 = createSprite(248,255);
  var ghostblock38 = createSprite(245,225);
  var ghostblock39 = createSprite(50,280);
  var ghostblock40 = createSprite(80,280);
  var ghostblock41 = createSprite(120,285);
  var ghostblock42 = createSprite(155,285);
  var ghostblock43 = createSprite(183,285);
  var ghostblock44 = createSprite(183,255);
  var ghostblock45 = createSprite(350,280);
  var ghostblock46 = createSprite(320,280);
  var ghostblock47 = createSprite(280,285);
  var ghostblock48 = createSprite(245,285);
  var ghostblock49 = createSprite(217,285);
  var ghostblock50 = createSprite(217,255);
  var ghostblock51 = createSprite(50,314);
  var ghostblock52 = createSprite(80,314);
  var ghostblock53 = createSprite(120,314);
  var ghostblock54 = createSprite(155,314);
  var ghostblock55 = createSprite(183,314);
  var ghostblock56 = createSprite(350,314);
  var ghostblock57 = createSprite(320,314);
  var ghostblock58 = createSprite(280,314);
  var ghostblock59 = createSprite(245,314);
  var ghostblock60 = createSprite(217,314);
  var ghostblock61 = createSprite(45,343);
  var ghostblock62 = createSprite(180,343);
  var ghostblock63 = createSprite(220,343);
  var ghostblock64 = createSprite(355,343);
  var ghostblock65 = createSprite(200,180);
  promptDR.add(ghostblock1);
  promptDT.add(ghostblock2);
  promptDT.add(ghostblock3);
  promptDL.add(ghostblock4);
  promptDL.add(ghostblock5);
  promptDR.add(ghostblock6);
  promptRT.add(ghostblock7);
  promptAny.add(ghostblock8);
  promptDT.add(ghostblock9);
  promptUT.add(ghostblock10);
  promptUT.add(ghostblock11);
  promptAny.add(ghostblock12);
  promptLT.add(ghostblock13);
  promptDT.add(ghostblock14);
  promptUR.add(ghostblock15);
  promptLT.add(ghostblock16);
  promptUR.add(ghostblock17);
  promptDL.add(ghostblock18);
  promptDR.add(ghostblock19);
  promptUL.add(ghostblock20);
  promptRT.add(ghostblock21);
  promptUL.add(ghostblock22);
  promptAny.add(ghostblock23);
  promptLT.add(ghostblock24);
  promptDR.add(ghostblock25);
  promptUT.add(ghostblock26);
  promptAny.add(ghostblock27);
  promptRT.add(ghostblock28);
  promptDL.add(ghostblock29);
  promptUT.add(ghostblock30);
  promptAny.add(ghostblock31);
  promptDR.add(ghostblock32);
  promptUT.add(ghostblock33);
  promptRT.add(ghostblock34);
  promptAny.add(ghostblock35);
  promptDL.add(ghostblock36);
  promptUT.add(ghostblock37);
  promptLT.add(ghostblock38);
  promptUR.add(ghostblock39);
  promptDL.add(ghostblock40);
  promptRT.add(ghostblock41);
  promptDT.add(ghostblock42);
  promptUT.add(ghostblock43);
  promptDL.add(ghostblock44);
  promptUL.add(ghostblock45);
  promptDR.add(ghostblock46);
  promptLT.add(ghostblock47);
  promptDT.add(ghostblock48);
  promptUT.add(ghostblock49);
  promptDR.add(ghostblock50);
  promptDR.add(ghostblock51);
  promptUT.add(ghostblock52);
  promptUL.add(ghostblock53);
  promptUR.add(ghostblock54);
  promptDL.add(ghostblock55);
  promptDL.add(ghostblock56);
  promptUT.add(ghostblock57);
  promptUR.add(ghostblock58);
  promptUL.add(ghostblock59);
  promptDR.add(ghostblock60);
  promptUR.add(ghostblock61);
  promptUT.add(ghostblock62);
  promptUT.add(ghostblock63);
  promptUL.add(ghostblock64);
  promptU.add(ghostblock65);
  promptAny.setScaleEach(0.025);
  promptUR.setScaleEach(0.025);
  promptDR.setScaleEach(0.025);
  promptUL.setScaleEach(0.025);
  promptDL.setScaleEach(0.025);
  promptUT.setScaleEach(0.025);
  promptDT.setScaleEach(0.025);
  promptRT.setScaleEach(0.025);
  promptLT.setScaleEach(0.025);
  promptU.setScaleEach(0.1);
  var dots = createGroup();
  var dot1 = createSprite(45,345);
  var dot2 = createSprite(60,345);
  var dot3 = createSprite(75,345);
  var dot4 = createSprite(90,345);
  var dot5 = createSprite(105,345);
  var dot6 = createSprite(120,345);
  var dot7 = createSprite(135,345);
  var dot8 = createSprite(150,345);
  var dot9 = createSprite(165,345);
  var dot10 = createSprite(180,345);
  var dot11 = createSprite(195,345);
  var dot12 = createSprite(210,345);
  var dot13 = createSprite(225,345);
  var dot14 = createSprite(240,345);
  var dot15 = createSprite(255,345);
  var dot16 = createSprite(270,345);
  var dot17 = createSprite(285,345);
  var dot18 = createSprite(300,345);
  var dot19 = createSprite(315,345);
  var dot20 = createSprite(330,345);
  var dot21 = createSprite(345,345);
  var dot22 = createSprite(360,345);
  var dot23 = createSprite(45,330);
  var dot24 = createSprite(45,315);
  var dot25 = createSprite(60,315);
  var dot26 = createSprite(75,315);
  var dot27 = createSprite(90,315);
  var dot28 = createSprite(105,315);
  var dot29 = createSprite(120,315);
  var dot30 = createSprite(120,300);
  var dot31 = createSprite(120,285);
  var dot32 = createSprite(135,285);
  var dot33 = createSprite(150,285);
  var dot34 = createSprite(165,285);
  var dot35 = createSprite(156,300);
  var dot36 = createSprite(156,315);
  var dot37 = createSprite(171,315);
  var dot38 = createSprite(186,315);
  var dot39 = createSprite(180,330);
  var dot40 = createSprite(355,330);
  var dot41 = createSprite(355,315);
  var dot42 = createSprite(340,315);
  var dot43 = createSprite(325,315);
  var dot44 = createSprite(310,315);
  var dot45 = createSprite(295,315);
  var dot46 = createSprite(280,315);
  var dot47 = createSprite(280,300);
  var dot48 = createSprite(280,285);
  var dot49 = createSprite(265,285);
  var dot50 = createSprite(250,285);
  var dot51 = createSprite(235,285);
  var dot52 = createSprite(244,300);
  var dot53 = createSprite(244,315);
  var dot54 = createSprite(229,315);
  var dot55 = createSprite(214,315);
  var dot56 = createSprite(220,330);
  var dot57 = createSprite(83,298);
  var dot58 = createSprite(83,280);
  var dot59 = createSprite(65,280);
  var dot60 = createSprite(48,280);
  var dot62 = createSprite(48,250);
  var dot63 = createSprite(63,250);
  var dot64 = createSprite(78,250);
  var dot65 = createSprite(93,250);
  var dot66 = createSprite(108,250);
  var dot67 = createSprite(120,250);
  var dot68 = createSprite(120,268);
  var dot69 = createSprite(135,257);
  var dot70 = createSprite(150,257);
  var dot71 = createSprite(165,257);
  var dot72 = createSprite(180,257);
  var dot73 = createSprite(183,272);
  var dot74 = createSprite(183,285);
  var dot75 = createSprite(317,298);
  var dot76 = createSprite(317,280);
  var dot77 = createSprite(335,280);
  var dot78 = createSprite(352,280);
  var dot80 = createSprite(352,250);
  var dot81 = createSprite(337,250);
  var dot82 = createSprite(322,250);
  var dot83 = createSprite(307,250);
  var dot84 = createSprite(292,250);
  var dot85 = createSprite(280,250);
  var dot86 = createSprite(280,268);
  var dot87 = createSprite(265,257);
  var dot88 = createSprite(250,257);
  var dot89 = createSprite(235,257);
  var dot90 = createSprite(220,257);
  var dot91 = createSprite(217,272);
  var dot92 = createSprite(217,285);
  var dot94 = createSprite(120,235);
  var dot95 = createSprite(120,220);
  var dot96 = createSprite(120,205);
  var dot97 = createSprite(120,190);
  var dot98 = createSprite(120,175);
  var dot99 = createSprite(120,160);
  var dot100 = createSprite(120,145);
  var dot101 = createSprite(120,130);
  var dot102 = createSprite(120,115);
  var dot103 = createSprite(120,100);
  var dot104 = createSprite(120,85);
  var dot105 = createSprite(120,70);
  var dot106 = createSprite(120,55);
  var dot107 = createSprite(120,35);
  var dot108 = createSprite(105,35);
  var dot109 = createSprite(90,35);
  var dot110 = createSprite(75,35);
  var dot111 = createSprite(60,35);
  var dot112 = createSprite(45,35);
  var dot114 = createSprite(45,65);
  var dot115 = createSprite(45,80);
  var dot116 = createSprite(45,95);
  var dot117 = createSprite(45,110);
  var dot118 = createSprite(60,110);
  var dot119 = createSprite(75,110);
  var dot120 = createSprite(90,110);
  var dot121 = createSprite(105,110);
  var dot122 = createSprite(60,80);
  var dot123 = createSprite(75,80);
  var dot124 = createSprite(90,80);
  var dot125 = createSprite(105,80);
  var dot126 = createSprite(280,235);
  var dot127 = createSprite(280,220);
  var dot128 = createSprite(280,205);
  var dot129 = createSprite(280,190);
  var dot130 = createSprite(280,175);
  var dot131 = createSprite(280,160);
  var dot132 = createSprite(280,145);
  var dot133 = createSprite(280,130);
  var dot134 = createSprite(280,115);
  var dot135 = createSprite(280,100);
  var dot136 = createSprite(280,85);
  var dot137 = createSprite(280,70);
  var dot138 = createSprite(280,55);
  var dot139 = createSprite(280,35);
  var dot140 = createSprite(295,35);
  var dot141 = createSprite(310,35);
  var dot142 = createSprite(325,35);
  var dot143 = createSprite(340,35);
  var dot144 = createSprite(355,35);
  var dot146 = createSprite(355,65);
  var dot147 = createSprite(355,80);
  var dot148 = createSprite(355,95);
  var dot149 = createSprite(355,110);
  var dot150 = createSprite(340,110);
  var dot151 = createSprite(325,110);
  var dot152 = createSprite(310,110);
  var dot153 = createSprite(295,110);
  var dot154 = createSprite(340,80);
  var dot155 = createSprite(325,80);
  var dot156 = createSprite(310,80);
  var dot157 = createSprite(295,80);
  var dot158 = createSprite(140,32);
  var dot159 = createSprite(155,32);
  var dot160 = createSprite(170,32);
  var dot161 = createSprite(185,32);
  var dot162 = createSprite(185,47);
  var dot163 = createSprite(185,62);
  var dot164 = createSprite(185,77);
  var dot165 = createSprite(170,77);
  var dot166 = createSprite(155,77);
  var dot167 = createSprite(140,77);
  var dot168 = createSprite(150,92);
  var dot169 = createSprite(153,107);
  var dot170 = createSprite(168,107);
  var dot171 = createSprite(183,107);
  var dot172 = createSprite(183,123);
  var dot173 = createSprite(260,32);
  var dot174 = createSprite(245,32);
  var dot175 = createSprite(230,32);
  var dot176 = createSprite(215,32);
  var dot177 = createSprite(215,47);
  var dot178 = createSprite(215,62);
  var dot179 = createSprite(215,77);
  var dot180 = createSprite(230,77);
  var dot181 = createSprite(245,77);
  var dot182 = createSprite(260,77);
  var dot183 = createSprite(250,92);
  var dot184 = createSprite(247,107);
  var dot185 = createSprite(232,107);
  var dot186 = createSprite(217,107);
  var dot187 = createSprite(217,123);
  dots.add(dot1);
  dots.add(dot2);
  dots.add(dot3);
  dots.add(dot4);
  dots.add(dot5);
  dots.add(dot6);
  dots.add(dot7);
  dots.add(dot8);
  dots.add(dot9);
  dots.add(dot10);
  dots.add(dot11);
  dots.add(dot12);
  dots.add(dot13);
  dots.add(dot14);
  dots.add(dot15);
  dots.add(dot16);
  dots.add(dot17);
  dots.add(dot18);
  dots.add(dot19);
  dots.add(dot20);
  dots.add(dot21);
  dots.add(dot22);
  dots.add(dot23);
  dots.add(dot24);
  dots.add(dot25);
  dots.add(dot26);
  dots.add(dot27);
  dots.add(dot28);
  dots.add(dot29);
  dots.add(dot30);
  dots.add(dot31);
  dots.add(dot32);
  dots.add(dot33);
  dots.add(dot34);
  dots.add(dot35);
  dots.add(dot36);
  dots.add(dot37);
  dots.add(dot38);
  dots.add(dot39);
  dots.add(dot40);
  dots.add(dot41);
  dots.add(dot42);
  dots.add(dot43);
  dots.add(dot44);
  dots.add(dot45);
  dots.add(dot46);
  dots.add(dot47);
  dots.add(dot48);
  dots.add(dot49);
  dots.add(dot50);
  dots.add(dot51);
  dots.add(dot52);
  dots.add(dot53);
  dots.add(dot54);
  dots.add(dot55);
  dots.add(dot56);
  dots.add(dot57);
  dots.add(dot58);
  dots.add(dot59);
  dots.add(dot60);
  dots.add(dot62);
  dots.add(dot63);
  dots.add(dot64);
  dots.add(dot65);
  dots.add(dot66);
  dots.add(dot67);
  dots.add(dot68);
  dots.add(dot69);
  dots.add(dot70);
  dots.add(dot71);
  dots.add(dot72);
  dots.add(dot73);
  dots.add(dot74);
  dots.add(dot75);
  dots.add(dot76);
  dots.add(dot77);
  dots.add(dot78);
  dots.add(dot80);
  dots.add(dot81);
  dots.add(dot82);
  dots.add(dot83);
  dots.add(dot84);
  dots.add(dot85);
  dots.add(dot86);
  dots.add(dot87);
  dots.add(dot88);
  dots.add(dot89);
  dots.add(dot90);
  dots.add(dot91);
  dots.add(dot92);
  dots.add(dot94);
  dots.add(dot95);
  dots.add(dot96);
  dots.add(dot97);
  dots.add(dot98);
  dots.add(dot99);
  dots.add(dot100);
  dots.add(dot101);
  dots.add(dot102);
  dots.add(dot103);
  dots.add(dot104);
  dots.add(dot105);
  dots.add(dot106);
  dots.add(dot107);
  dots.add(dot108);
  dots.add(dot109);
  dots.add(dot110);
  dots.add(dot111);
  dots.add(dot112);
  dots.add(dot114);
  dots.add(dot115);
  dots.add(dot116);
  dots.add(dot117);
  dots.add(dot118);
  dots.add(dot119);
  dots.add(dot120);
  dots.add(dot121);
  dots.add(dot122);
  dots.add(dot123);
  dots.add(dot124);
  dots.add(dot125);
  dots.add(dot126);
  dots.add(dot127);
  dots.add(dot128);
  dots.add(dot129);
  dots.add(dot130);
  dots.add(dot131);
  dots.add(dot132);
  dots.add(dot133);
  dots.add(dot134);
  dots.add(dot135);
  dots.add(dot136);
  dots.add(dot137);
  dots.add(dot138);
  dots.add(dot139);
  dots.add(dot140);
  dots.add(dot141);
  dots.add(dot142);
  dots.add(dot143);
  dots.add(dot144);
  dots.add(dot146);
  dots.add(dot147);
  dots.add(dot148);
  dots.add(dot149);
  dots.add(dot150);
  dots.add(dot151);
  dots.add(dot152);
  dots.add(dot153);
  dots.add(dot154);
  dots.add(dot155);
  dots.add(dot156);
  dots.add(dot157);
  dots.add(dot158);
  dots.add(dot159);
  dots.add(dot160);
  dots.add(dot161);
  dots.add(dot162);
  dots.add(dot163);
  dots.add(dot164);
  dots.add(dot165);
  dots.add(dot166);
  dots.add(dot167);
  dots.add(dot168);
  dots.add(dot169);
  dots.add(dot170);
  dots.add(dot171);
  dots.add(dot172);
  dots.add(dot173);
  dots.add(dot174);
  dots.add(dot175);
  dots.add(dot176);
  dots.add(dot177);
  dots.add(dot178);
  dots.add(dot179);
  dots.add(dot180);
  dots.add(dot181);
  dots.add(dot182);
  dots.add(dot183);
  dots.add(dot184);
  dots.add(dot185);
  dots.add(dot186);
  dots.add(dot187);
  dots.setScaleEach(0.05);
  dots.setAnimationEach("yellow");
  var eatGhost = createGroup();
  var ghostdot1 = createSprite(352,265);
  var ghostdot2 = createSprite(48,265);
  var ghostdot3 = createSprite(355,50);
  var ghostdot4 = createSprite(45,50);
  eatGhost.add(ghostdot1);
  eatGhost.add(ghostdot2);
  eatGhost.add(ghostdot3);
  eatGhost.add(ghostdot4);
  eatGhost.setAnimationEach("circle");
  eatGhost.setColliderEach("circle");
  eatGhost.setScaleEach(0.15);
  var debug = 1;
var timer1 = 0;
var blinkyStart1 = 1.5;
var timer2 = 0;
var inkyStart1 = -1.5;
var timer3 = 0;
var pinkyStart1 = -1.5;
var timer4 = 0;
var clydeStart1 = 1.5;
var blinkyMove = 0;
var blinkyIntReset = 0;
var blinkyIntReset2 = 0;
var inkyMove = 0;
var inkyIntReset = 0;
var inkyIntReset2 = 0;
var pinkyMove = 0;
var pinkyIntReset = 0;
var pinkyIntReset2 = 0;
var clydeMove = 0;
var clydeIntReset = 0;
var clydeIntReset2 = 0;
var deathTimer = 0;
var death1 = 0;
var alive = true;
var deathreset = 1;
var sound1 = 1;
var lives = 3;
var ready = 1;
var sound2 = 1;
var startTimer = 0;
var animationStart = 0;
var score = 0;
var scoreTimer = 0;
var scoreReset = 0;
var ghostEatStart = 0;
var ghostEat = 0;
var ghostTimer = 0;
var ghostTally = 0;
var BlinkyAlive = 0;
var InkyAlive = 0;
var PinkyAlive = 0;
var ClydeAlive = 0;
var berryTimer1 = 0;
var berryTimer2 = 0;
var berryTimer3 = 0;
var berryTimer4 = 0;
var berryTimer5 = 0;
var cherrycheck = 0;
var strawcheck = 0;
var orangecheck = 0;
var applecheck = 0;
var meloncheck = 0;
var cherryEat = 0;
var strawEat = 0;
var orangeEat = 0;
var appleEat = 0;
var dotCount = 0;
var winset = 1;
var winDirection = 0;
  var cherry = createSprite(999,999);
  cherry.setAnimation("Cherry");
  cherry.scale = 0.18;
  var straw = createSprite(999,999);
  straw.setAnimation("strawberry");
  straw.scale = 0.18;
  var orange = createSprite(999,999);
  orange.setAnimation("orange");
  orange.scale = 0.18;
  var apple = createSprite(999,999);
  apple.setAnimation("apple");
  apple.scale = 0.18;
  var melon = createSprite(999,999);
  melon.setAnimation("melon");
  melon.scale = 0.18;
  var winDot = createSprite(385,600);
  winDot.setAnimation("circle");
  winDot.scale = 0.15;
  var winPac = createSprite(125,600);
  winPac.setAnimation("R_Pac");
  winPac.scale = 0.18;
var Pac = createSprite(200,285);
Pac.setAnimation("L_Pac");
Pac.scale = 0.18;
Pac.setCollider("circle");
var pacMove = 0;
var ghosts = createGroup();
var Blinky = createSprite(188,168);
Blinky.setAnimation("L_Blinky");
Blinky.scale = 0.18;
Blinky.setCollider("circle");
ghosts.add(Blinky);
var Clyde = createSprite(188,188);
Clyde.setAnimation("L_Clyde");
Clyde.scale = 0.18;
Clyde.setCollider("circle");
ghosts.add(Clyde);
var Inky = createSprite(210,168);
Inky.setAnimation("L_Inky");
Inky.scale = 0.18;
Inky.setCollider("circle");
ghosts.add(Inky);
var Pinky = createSprite(210,188);
Pinky.setAnimation("L_Pinky");
Pinky.scale = 0.18;
Pinky.setCollider("circle");
ghosts.add(Pinky);
  var lifeSprites = createGroup();
  var life1 = createSprite(25,383);
  var life2 = createSprite(50,383);
  var life3 = createSprite(75,383);
  var life4 = createSprite(100,383);
  var life5 = createSprite(125,383);
  var life6 = createSprite(150,383);
  var life7 = createSprite(175,383);
  lifeSprites.add(life1);
  lifeSprites.add(life2);
  lifeSprites.add(life3);
  lifeSprites.add(life4);
  lifeSprites.add(life5);
  lifeSprites.add(life6);
  lifeSprites.add(life7);
  lifeSprites.setAnimationEach("stationary_Pac");
  lifeSprites.setScaleEach(0.2);
//Draw
function draw() {
  background(color);
  debug1();
  if (dotCount < 181){
  ghostAnimations();
  }
  borders();
  start();
  if (ready === 0){
  movement();
  movement2();
  if (dotCount < 182){
  blinkyStart();
  blinkyMovement();
  blinkyIntersections();
  blinkyIntersectionReset();
  inkyStart();
  inkyMovement();
  inkyIntersections();
  inkyIntersectionReset();
  pinkyStart();
  pinkyMovement();
  pinkyIntersections();
  pinkyIntersectionReset();
  clydeStart();
  clydeMovement();
  clydeIntersections();
  clydeIntersectionReset();
  }
  }
  score1();
  destroydots();
  lives1();
  death();
  end();
  ghostdots();
  eatingGhosts();
  cherry1();
  strawberry1();
  orange1();
  apple1();
  melon1();
  win();
  drawSprites();
}
function movement(){
  if (alive === true){
  if (keyWentDown("left")){
    Pac.setAnimation("L_Pac");
    pacMove = 1;
  }
  if (keyWentDown("right")){
    Pac.setAnimation("R_Pac");
    pacMove = 2;
  }
  if (keyWentDown("up")){
    Pac.setAnimation("U_Pac");
    pacMove = 3;
  }
  if (keyWentDown("down")){
    Pac.setAnimation("D_Pac");
    pacMove = 4;
  }
  }
}
function movement2(){
  if (alive === true){
  if (pacMove === 1){
    Pac.velocityX = -2.5;
    Pac.velocityY = 0;
  }
  if (pacMove === 2){
    Pac.velocityX = 2.5;
    Pac.velocityY = 0;
  }
  if (pacMove === 3){
    Pac.velocityX = 0;
    Pac.velocityY = -2.5;
  }
  if (pacMove === 4){
    Pac.velocityX = 0;
    Pac.velocityY = 2.5;
  }
  if (Pac.x > 405){
    Pac.x = -3;
  }
  if (Pac.x < -5){
    Pac.x = 403;
  }
  }
}
function ghostAnimations(){
  
if (BlinkyAlive === 0){
  if (Blinky.velocityX > 0){
    Blinky.setAnimation("R_Blinky");
  }
  if (Blinky.velocityX < 0){
    Blinky.setAnimation("L_Blinky");
  }
  if (Blinky.velocityY > 0){
    Blinky.setAnimation("D_Blinky");
  }
  if (Blinky.velocityY < 0){
    Blinky.setAnimation("U_Blinky");
  }
  }
if (ClydeAlive === 0){
  if (Clyde.velocityX > 0){
    Clyde.setAnimation("R_Clyde");
  }
  if (Clyde.velocityX < 0){
    Clyde.setAnimation("L_Clyde");
  }
  if (Clyde.velocityY > 0){
    Clyde.setAnimation("D_Clyde");
  }
  if (Clyde.velocityY < 0){
    Clyde.setAnimation("U_Clyde");
  }
  }
if (InkyAlive == 0){
  if (Inky.velocityX > 0){
    Inky.setAnimation("R_Inky");
  }
  if (Inky.velocityX < 0){
    Inky.setAnimation("L_Inky");
  }
  if (Inky.velocityY > 0){
    Inky.setAnimation("D_Inky");
  }
  if (Inky.velocityY < 0){
    Inky.setAnimation("U_Inky");
  }
}
if (PinkyAlive == 0){
  if (Pinky.velocityX > 0){
    Pinky.setAnimation("R_Pinky");
  }
  if (Pinky.velocityX < 0){
    Pinky.setAnimation("L_Pinky");
  }
  if (Pinky.velocityY > 0){
    Pinky.setAnimation("D_Pinky");
  }
  if (Pinky.velocityY < 0){
    Pinky.setAnimation("U_Pinky");
  }
}
}

function blinkyStart(){

  if (timer1 < 125){
  timer1 = timer1 + 1;
  }
  if (timer1 < 100){
  if (timer1 < 25){
    Blinky.velocityX = blinkyStart1;
    }
  if (timer1 > 25 && timer1 < 50){
    Blinky.velocityX = -blinkyStart1;
    }
  if (timer1 > 50 && timer1 < 75){
    Blinky.velocityX = blinkyStart1;
    }
  if (timer1 > 75 && timer1 < 100){
    Blinky.velocityX = -blinkyStart1;
  }
  }
  if (timer1 > 75 && Blinky.isTouching(promptU)){
    Blinky.velocityY = -1.5;
  }
}

function blinkyMovement(){
  if (blinkyMove === 1 || blinkyMove === 5 || blinkyMove === 7 || blinkyMove === 11 || blinkyMove === 15){
    Blinky.velocityX = 2;
    Blinky.velocityY = 0;
  }
  if (blinkyMove === 2 || blinkyMove === 10 || blinkyMove === 14){
    Blinky.velocityX = -2;
    Blinky.velocityY = 0;
  }
  if (blinkyMove === 3 || blinkyMove === 6 || blinkyMove === 12){
    Blinky.velocityX = 0;
    Blinky.velocityY = -2;
  }
  if (blinkyMove === 4 || blinkyMove === 8 || blinkyMove === 9 || blinkyMove === 13){
    Blinky.velocityX = 0;
    Blinky.velocityY = 2;
  }
}
function blinkyIntersections(){
  
  if (Blinky.isTouching(promptUL)&& blinkyIntReset < 1){
    blinkyMove = randomNumber(2,3);
    blinkyIntReset2 = 1;
  }
  if (Blinky.isTouching(promptUT)&& blinkyIntReset < 1){
    blinkyMove = randomNumber(1,3);
    blinkyIntReset2 = 1;
  }
  if (Blinky.isTouching(promptLT)&& blinkyIntReset < 1){
    blinkyMove =  randomNumber(2,4);
    blinkyIntReset2 = 1;
  }
  if (Blinky.isTouching(promptAny) && blinkyIntReset < 1){
    blinkyMove = randomNumber(1,4);
    blinkyIntReset2 = 1;
  }
  if (Blinky.isTouching(promptUR)&& blinkyIntReset < 1){
    blinkyMove = randomNumber(5,6);
    blinkyIntReset2 = 1;
  }
  if (Blinky.isTouching(promptDR)&& blinkyIntReset < 1){
    blinkyMove = randomNumber(7,8);
    blinkyIntReset2 = 1;
  }
  if (Blinky.isTouching(promptDL)&& blinkyIntReset < 1){
    blinkyMove = randomNumber(9,10);
    blinkyIntReset2 = 1;
  }
  if (Blinky.isTouching(promptRT)&& blinkyIntReset < 1){
    blinkyMove = randomNumber(11,13);
    blinkyIntReset2 = 1;
  }
  if (Blinky.isTouching(promptDT)&& blinkyIntReset < 1){
    blinkyMove = randomNumber(13,15);
    blinkyIntReset2 = 1;
  }
}
function blinkyIntersectionReset(){
  if (blinkyIntReset2 === 1){
    blinkyIntReset = blinkyIntReset + 1;
  }
  if (blinkyIntReset > 15){
    blinkyIntReset2 = 0;
    blinkyIntReset = 0;
  }
  if (Blinky.x > 405 && dotCount < 181){
    Blinky.x = -3;
  }
  if (Blinky.x < -5 && dotCount < 181){
    Blinky.x = 403;
  }
}
function inkyStart(){
  if (timer2 < 250){
  timer2 = timer2 + 1;
  }
  if (timer2 < 225){
  if (timer2 < 25){
    Inky.velocityX = inkyStart1;
    }
  if (timer2 > 25 && timer2 < 50){
    Inky.velocityX = -inkyStart1;
    }
  if (timer2 > 50 && timer2 < 75){
    Inky.velocityX = inkyStart1;
    }
  if (timer2 > 75 && timer2 < 100){
    Inky.velocityX = -inkyStart1;
  }
  if (timer2 > 100 && timer2 < 125){
    Inky.velocityX = inkyStart1;
  }
  if (timer2 > 125 && timer2 < 150){
    Inky.velocityX = -inkyStart1;
  }
  
  }
  if (timer2 > 125 && Inky.isTouching(promptU)){
    Inky.velocityY = -1.5;
    
  }
}
function inkyMovement(){
  if (inkyMove === 1 || inkyMove === 5 || inkyMove === 7 || inkyMove === 11 || inkyMove === 15){
    Inky.velocityX = 2;
    Inky.velocityY = 0;
  }
  if (inkyMove === 2 || inkyMove === 10 || inkyMove === 14){
    Inky.velocityX = -2;
    Inky.velocityY = 0;
  }
  if (inkyMove === 3 || inkyMove === 6 || inkyMove === 12){
    Inky.velocityX = 0;
    Inky.velocityY = -2;
  }
  if (inkyMove === 4 || inkyMove === 8 || inkyMove === 9 || inkyMove === 13){
    Inky.velocityX = 0;
    Inky.velocityY = 2;
  }
}
function inkyIntersections(){
  
  if (Inky.isTouching(promptUL)&& inkyIntReset < 1){
    inkyMove = randomNumber(2,3);
    inkyIntReset2 = 1;
  }
  if (Inky.isTouching(promptUT)&& inkyIntReset < 1){
    inkyMove = randomNumber(1,3);
    inkyIntReset2 = 1;
  }
  if (Inky.isTouching(promptLT)&& inkyIntReset < 1){
    inkyMove =  randomNumber(2,4);
    inkyIntReset2 = 1;
  }
  if (Inky.isTouching(promptAny) && inkyIntReset < 1){
    inkyMove = randomNumber(1,4);
    inkyIntReset2 = 1;
  }
  if (Inky.isTouching(promptUR)&& inkyIntReset < 1){
    inkyMove = randomNumber(5,6);
    inkyIntReset2 = 1;
  }
  if (Inky.isTouching(promptDR)&& inkyIntReset < 1){
    inkyMove = randomNumber(7,8);
    inkyIntReset2 = 1;
  }
  if (Inky.isTouching(promptDL)&& inkyIntReset < 1){
    inkyMove = randomNumber(9,10);
    inkyIntReset2 = 1;
  }
  if (Inky.isTouching(promptRT)&& inkyIntReset < 1){
    inkyMove = randomNumber(11,13);
    inkyIntReset2 = 1;
  }
  if (Inky.isTouching(promptDT)&& inkyIntReset < 1){
    inkyMove = randomNumber(13,15);
    inkyIntReset2 = 1;
  }
}
function inkyIntersectionReset(){
  if (inkyIntReset2 === 1){
    inkyIntReset = inkyIntReset + 1;
  }
  if (inkyIntReset > 15){
    inkyIntReset2 = 0;
    inkyIntReset = 0;
  }
  if (Inky.x > 405 && dotCount < 181){
    Inky.x = -3;
  }
  if (Inky.x < -5 && dotCount < 181){
    Inky.x = 403;
  }
}
function pinkyStart(){
  if (timer3 < 300){
  timer3 = timer3 + 1;
  }
  if (timer3 < 275){
  if (timer3 < 25){
    Pinky.velocityX = pinkyStart1;
    }
  if (timer3 > 25 && timer3 < 50){
    Pinky.velocityX = -pinkyStart1;
    }
  if (timer3 > 50 && timer3 < 75){
    Pinky.velocityX = pinkyStart1;
    }
  if (timer3 > 75 && timer3 < 100){
    Pinky.velocityX = -pinkyStart1;
  }
  if (timer3 > 100 && timer3 < 125){
    Pinky.velocityX = pinkyStart1;
  }
  if (timer3 > 125 && timer3 < 150){
    Pinky.velocityX = -pinkyStart1;
  }
  if (timer3 > 150 && timer3 < 175){
    Pinky.velocityX = pinkyStart1;
  }
  if (timer3 > 175 && timer3 < 200){
    Pinky.velocityX = -pinkyStart1;
  }
  }
  if (timer3 > 175 && Pinky.isTouching(promptU)){
    Pinky.velocityY = -1.5;
    Pinky.velocityX = 0;
    
  }
}
function pinkyMovement(){
  if (pinkyMove === 1 || pinkyMove === 5 || pinkyMove === 7 || pinkyMove === 11 || pinkyMove === 15){
    Pinky.velocityX = 2;
    Pinky.velocityY = 0;
  }
  if (pinkyMove === 2 || pinkyMove === 10 || pinkyMove === 14){
    Pinky.velocityX = -2;
    Pinky.velocityY = 0;
  }
  if (pinkyMove === 3 || pinkyMove === 6 || pinkyMove === 12){
    Pinky.velocityX = 0;
    Pinky.velocityY = -2;
  }
  if (pinkyMove === 4 || pinkyMove === 8 || pinkyMove === 9 || pinkyMove === 13){
    Pinky.velocityX = 0;
    Pinky.velocityY = 2;
  }
}
function pinkyIntersections(){
  if (Pinky.isTouching(promptUL)&& pinkyIntReset < 1){
    pinkyMove = randomNumber(2,3);
    pinkyIntReset2 = 1;
  }
  if (Pinky.isTouching(promptUT)&& pinkyIntReset < 1){
    pinkyMove = randomNumber(1,3);
    pinkyIntReset2 = 1;
  }
  if (Pinky.isTouching(promptLT)&& pinkyIntReset < 1){
    pinkyMove =  randomNumber(2,4);
    pinkyIntReset2 = 1;
  }
  if (Pinky.isTouching(promptAny) && pinkyIntReset < 1){
    pinkyMove = randomNumber(1,4);
    pinkyIntReset2 = 1;
  }
  if (Pinky.isTouching(promptUR)&& pinkyIntReset < 1){
    pinkyMove = randomNumber(5,6);
    pinkyIntReset2 = 1;
  }
  if (Pinky.isTouching(promptDR)&& pinkyIntReset < 1){
    pinkyMove = randomNumber(7,8);
    pinkyIntReset2 = 1;
  }
  if (Pinky.isTouching(promptDL)&& pinkyIntReset < 1){
    pinkyMove = randomNumber(9,10);
    pinkyIntReset2 = 1;
  }
  if (Pinky.isTouching(promptRT)&& pinkyIntReset < 1){
    pinkyMove = randomNumber(11,13);
    pinkyIntReset2 = 1;
  }
  if (Pinky.isTouching(promptDT)&& pinkyIntReset < 1){
    pinkyMove = randomNumber(13,15);
    pinkyIntReset2 = 1;
  }
}
function pinkyIntersectionReset(){
  if (pinkyIntReset2 === 1){
    pinkyIntReset = pinkyIntReset + 1;
  }
  if (pinkyIntReset > 15){
    pinkyIntReset2 = 0;
    pinkyIntReset = 0;
  }
  if (Pinky.x > 405 && dotCount < 181){
    Pinky.x = -3;
  }
  if (Pinky.x < -5 && dotCount < 181){
    Pinky.x = 403;
  }
}
function clydeStart(){
  if (timer4 < 300){
  timer4 = timer4 + 1;
  }
  if (timer4 < 275){
  if (timer4 < 25){
    Clyde.velocityX = clydeStart1;
    }
  if (timer4 > 25 && timer4 < 50){
    Clyde.velocityX = -clydeStart1;
    }
  if (timer4 > 50 && timer4 < 75){
    Clyde.velocityX = clydeStart1;
    }
  if (timer4 > 75 && timer4 < 100){
    Clyde.velocityX = -clydeStart1;
  }
  if (timer4 > 100 && timer4 < 125){
    Clyde.velocityX = clydeStart1;
  }
  if (timer4 > 125 && timer4 < 150){
    Clyde.velocityX = -clydeStart1;
  }
  if (timer4 > 150 && timer4 < 175){
    Clyde.velocityX = clydeStart1;
  }
  if (timer4 > 175 && timer4 < 200){
    Clyde.velocityX = -clydeStart1;
  }
  if (timer4 > 200 && timer4 < 225){
    Clyde.velocityX = clydeStart1;
  }
  if (timer4 > 225 && timer4 < 250){
    Clyde.velocityX = -clydeStart1;
  }
  }
  if (timer3 > 225 && Clyde.isTouching(promptU)){
    Clyde.velocityY = -1.5;
    Clyde.velocityX = 0;
    
  }
}
function clydeMovement(){
  if (clydeMove === 1 || clydeMove === 5 || clydeMove === 7 || clydeMove === 11 || clydeMove === 15){
    Clyde.velocityX = 2;
    Clyde.velocityY = 0;
  }
  if (clydeMove === 2 || clydeMove === 10 || clydeMove === 14){
    Clyde.velocityX = -2;
    Clyde.velocityY = 0;
  }
  if (clydeMove === 3 || clydeMove === 6 || clydeMove === 12){
    Clyde.velocityX = 0;
    Clyde.velocityY = -2;
  }
  if (clydeMove === 4 || clydeMove === 8 || clydeMove === 9 || clydeMove === 13){
    Clyde.velocityX = 0;
    Clyde.velocityY = 2;
  }
}
function clydeIntersections(){
  
  if (Clyde.isTouching(promptUL)&& clydeIntReset < 1){
    clydeMove = randomNumber(2,3);
    clydeIntReset2 = 1;
  }
  if (Clyde.isTouching(promptUT)&& clydeIntReset < 1){
    clydeMove = randomNumber(1,3);
    clydeIntReset2 = 1;
  }
  if (Clyde.isTouching(promptLT)&& clydeIntReset < 1){
    clydeMove =  randomNumber(2,4);
    clydeIntReset2 = 1;
  }
  if (Clyde.isTouching(promptAny) && clydeIntReset < 1){
    clydeMove = randomNumber(1,4);
    clydeIntReset2 = 1;
  }
  if (Clyde.isTouching(promptUR)&& clydeIntReset < 1){
    clydeMove = randomNumber(5,6);
    clydeIntReset2 = 1;
  }
  if (Clyde.isTouching(promptDR)&& clydeIntReset < 1){
    clydeMove = randomNumber(7,8);
    clydeIntReset2 = 1;
  }
  if (Clyde.isTouching(promptDL)&& clydeIntReset < 1){
    clydeMove = randomNumber(9,10);
    clydeIntReset2 = 1;
  }
  if (Clyde.isTouching(promptRT)&& clydeIntReset < 1){
    clydeMove = randomNumber(11,13);
    clydeIntReset2 = 1;
  }
  if (Clyde.isTouching(promptDT)&& clydeIntReset < 1){
    clydeMove = randomNumber(13,15);
    clydeIntReset2 = 1;
  }
}
function clydeIntersectionReset(){
  if (clydeIntReset2 === 1){
    clydeIntReset = clydeIntReset + 1;
  }
  if (clydeIntReset > 15){
    clydeIntReset2 = 0;
    clydeIntReset = 0;
  }
  if (Clyde.x > 405 && dotCount < 181){
    Clyde.x = -3;
  }
  if (Clyde.x < -5 && dotCount < 181){
    Clyde.x = 403;
  }
}
function borders(){
  Pac.collide(Borders);
  Pac.collide(border24);
  Blinky.collide(Borders);
  Pinky.collide(Borders);
  Clyde.collide(Borders);
  Inky.collide(Borders);
}
function score1(){
  fill("white");
  textSize(20);
  textFont("Courier New");
  text("Score " + score,275,389);
  text("AS", 190, 389);
  if (Pac.isTouching(dots)){
    score = score + 10;
  }
  if (Pac.isTouching(dots) && scoreReset === 0){
    playSound("assets/Chomp.mp3");
    scoreReset = 1;
  }
  if (scoreReset > 0){
    scoreTimer = scoreTimer + 1;
  }
  if (scoreTimer > 8){
    scoreTimer = 0;
    scoreReset = 0;
  }
  
}
function destroydots(){
  if (Pac.isTouching(dot1)){
    dot1.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot2)){
    dot2.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot3)){
    dot3.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot4)){
    dot4.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot5)){
    dot5.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot6)){
    dot6.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot7)){
    dot7.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot8)){
    dot8.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot9)){
    dot9.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot10)){
    dot10.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot11)){
    dot11.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot12)){
    dot12.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot13)){
    dot13.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot14)){
    dot14.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot15)){
    dot15.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot16)){
    dot16.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot17)){
    dot17.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot18)){
    dot18.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot19)){
    dot19.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot20)){
    dot20.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot21)){
    dot21.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot22)){
    dot22.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot23)){
    dot23.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot24)){
    dot24.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot25)){
    dot25.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot26)){
    dot26.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot27)){
    dot27.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot32)){
    dot32.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot28)){
    dot28.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot29)){
    dot29.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot30)){
    dot30.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot31)){
    dot31.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot33)){
    dot33.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot34)){
    dot34.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot35)){
    dot35.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot36)){
    dot36.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot37)){
    dot37.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot38)){
    dot38.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot39)){
    dot39.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot40)){
    dot40.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot41)){
    dot41.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot42)){
    dot42.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot43)){
    dot43.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot44)){
    dot44.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot45)){
    dot45.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot46)){
    dot46.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot47)){
    dot47.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot48)){
    dot48.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot49)){
    dot49.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot50)){
    dot50.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot51)){
    dot51.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot52)){
    dot52.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot53)){
    dot53.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot54)){
    dot54.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot55)){
    dot55.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot56)){
    dot56.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot57)){
    dot57.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot58)){
    dot58.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot59)){
    dot59.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot60)){
    dot60.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot62)){
    dot62.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot63)){
    dot63.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot64)){
    dot64.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot65)){
    dot65.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot66)){
    dot66.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot67)){
    dot67.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot68)){
    dot68.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot69)){
    dot69.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot70)){
    dot70.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot71)){
    dot71.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot72)){
    dot72.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot73)){
    dot73.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot74)){
    dot74.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot75)){
    dot75.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot76)){
    dot76.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot77)){
    dot77.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot78)){
    dot78.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot80)){
    dot80.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot81)){
    dot81.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot82)){
    dot82.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot83)){
    dot83.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot84)){
    dot84.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot85)){
    dot85.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot86)){
    dot86.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot87)){
    dot87.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot88)){
    dot88.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot89)){
    dot89.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot90)){
    dot90.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot91)){
    dot91.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot92)){
    dot92.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot94)){
    dot94.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot95)){
    dot95.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot96)){
    dot96.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot97)){
    dot97.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot98)){
    dot98.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot99)){
    dot99.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot100)){
    dot100.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot101)){
    dot101.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot102)){
    dot102.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot103)){
    dot103.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot104)){
    dot104.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot105)){
    dot105.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot106)){
    dot106.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot107)){
    dot107.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot108)){
    dot108.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot109)){
    dot109.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot110)){
    dot110.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot111)){
    dot111.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot112)){
    dot112.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot114)){
    dot114.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot115)){
    dot115.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot116)){
    dot116.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot117)){
    dot117.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot118)){
    dot118.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot119)){
    dot119.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot120)){
    dot120.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot121)){
    dot121.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot122)){
    dot122.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot123)){
    dot123.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot124)){
    dot124.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot125)){
    dot125.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot126)){
    dot126.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot127)){
    dot127.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot128)){
    dot128.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot129)){
    dot129.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot130)){
    dot130.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot131)){
    dot131.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot132)){
    dot132.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot133)){
    dot133.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot134)){
    dot134.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot135)){
    dot135.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot136)){
    dot136.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot137)){
    dot137.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot138)){
    dot138.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot139)){
    dot139.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot140)){
    dot140.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot141)){
    dot141.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot142)){
    dot142.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot143)){
    dot143.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot144)){
    dot144.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot146)){
    dot146.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot147)){
    dot147.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot148)){
    dot148.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot149)){
    dot149.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot150)){
    dot150.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot151)){
    dot151.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot152)){
    dot152.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot153)){
    dot153.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot154)){
    dot154.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot155)){
    dot155.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot156)){
    dot156.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot157)){
    dot157.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot158)){
    dot158.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot159)){
    dot159.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot160)){
    dot160.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot161)){
    dot161.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot162)){
    dot162.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot163)){
    dot163.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot164)){
    dot164.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot165)){
    dot165.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot166)){
    dot166.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot167)){
    dot167.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot168)){
    dot168.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot169)){
    dot169.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot170)){
    dot170.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot171)){
    dot171.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot172)){
    dot172.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot173)){
    dot173.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot174)){
    dot174.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot175)){
    dot175.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot176)){
    dot176.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot177)){
    dot177.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot178)){
    dot178.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot179)){
    dot179.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot180)){
    dot180.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot181)){
    dot181.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot182)){
    dot182.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot183)){
    dot183.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot184)){
    dot184.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot185)){
    dot185.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot186)){
    dot186.destroy();
    dotCount = dotCount + 1;
  }
  if (Pac.isTouching(dot187)){
    dot187.destroy();
    dotCount = dotCount + 1;
  }
  // ghost point dots
  if (Pac.isTouching(ghostdot1)){
    ghostdot1.destroy();
    ghostEatStart = 1;
    BlinkyAlive = 1;
    PinkyAlive = 1;
    InkyAlive = 1;
    ClydeAlive = 1;
  }
  if (Pac.isTouching(ghostdot2)){
    ghostdot2.destroy();
    ghostEatStart = 1;
    BlinkyAlive = 1;
    PinkyAlive = 1;
    InkyAlive = 1;
    ClydeAlive = 1;
  }
  if (Pac.isTouching(ghostdot3)){
    ghostdot3.destroy();
    ghostEatStart = 1;
    BlinkyAlive = 1;
    PinkyAlive = 1;
    InkyAlive = 1;
    ClydeAlive = 1;
  }
  if (Pac.isTouching(ghostdot4)){
    ghostdot4.destroy();
    ghostEatStart = 1;
    BlinkyAlive = 1;
    PinkyAlive = 1;
    InkyAlive = 1;
    ClydeAlive = 1;
  }
}

function lives1(){
  if (lives < 7){
    life7.setAnimation("black");
  }
  if (lives < 6){
    life6.setAnimation("black");
  }
  if (lives < 5){
    life5.setAnimation("black");
  }
  if (lives < 4){
    life4.setAnimation("black");
  }
  if (lives < 3){
    life3.setAnimation("black");
  }
  if (lives < 2){
    life2.setAnimation("black");
  }
  if (lives < 1){
    life1.setAnimation("black");
  }
}
function death(){
  if (Pac.isTouching(ghosts) && ghostEat === 0){
    death1 = 1;
    lives = lives - 1;
    sound1 = 1;
  }
  if (death1 === 1){
    if (sound1 === 1){
    playSound("assets/Death.mp3");
    sound1 = 0;
    }
    Pac.setAnimation("death");
    alive = false;
    Pac.velocityX = 0;
    Pac.velocityY = 0;
    deathTimer = deathTimer + 1;
    Blinky.x = 188;
    Blinky.y = 168;
    Blinky.velocityY = 0;
    Blinky.velocityX = 0;
    blinkyMove = 0;
    Clyde.x = 188;
    Clyde.y = 188;
    Clyde.velocityY = 0;
    Clyde.velocityX = 0;
    clydeMove = 0;
    Inky.x = 210;
    Inky.y = 168;
    Inky.velocityY = 0;
    Inky.velocityX = 0;
    inkyMove = 0;
    Pinky.x = 210;
    Pinky.y = 188;
    Pinky.velocityY = 0;
    Pinky.velocityX = 0;
    pinkyMove = 0;
    pacMove = 0;
    
    ghosts.setAnimationEach("black");
  }
  if (deathTimer > 36 && lives > 0.99){
    death1 = 0;
    deathTimer = 0;
    deathreset = 0;
    alive = true;
    Pac.x = 200;
    Pac.y = 285;
    Pac.setAnimation("R_Pac");
    timer1 = 0;
    timer2 = 0;
    timer3 = 0;
    timer4 = 0;
    
    Blinky.setAnimation("L_Blinky");
    Pinky.setAnimation("L_Pinky");
    Clyde.setAnimation("L_Clyde");
    Inky.setAnimation("L_Inky");
  }
}
function end(){
  if (lives < 1 && deathTimer > 36){
    alive = false;
    Pac.x = 999999;
    Pac.y = 999999;
    Blinky.x = -99999;
    Inky.x = -99999;
    Pinky.x = -99999;
    Clyde.x = -9999999;
    
    fill("red");
    textSize(17);
    textFont("Courier New");
    text("GAME OVER",150,230);
    promptLT.destroyEach();
  }
}
function debug1(){
  if (debug === 0){
    promptAny.setAnimationEach("Any");
  promptUR.setAnimationEach("UR");
  promptDR.setAnimationEach("DR");
  promptUL.setAnimationEach("UL");
  promptDL.setAnimationEach("DL");
  promptUT.setAnimationEach("UT");
  promptDT.setAnimationEach("DT");
  promptRT.setAnimationEach("RT");
  promptLT.setAnimationEach("LT");
  promptU.setAnimationEach("U");
  } else {
  promptAny.setAnimationEach("black");
  promptUR.setAnimationEach("black");
  promptDR.setAnimationEach("black");
  promptUL.setAnimationEach("black");
  promptDL.setAnimationEach("black");
  promptUT.setAnimationEach("black");
  promptDT.setAnimationEach("black");
  promptRT.setAnimationEach("black");
  promptLT.setAnimationEach("black");
  promptU.setAnimationEach("black");
  }
}
function start(){
  if (ready === 1){
    Pac.visible = false;
    
  } else {
    if (animationStart === 0){
      Pac.visible = true;
      animationStart = 1;
    }
  }
  if (sound2 === 1){
    sound2 = 0;
    playSound("assets/Intro.mp3");
  }
  startTimer = startTimer + 1;
  if (startTimer > 100){
    ready = 0;
  }
  if (ready === 1){
    fill("yellow");
    textSize(20);
    textFont("Courier New");
    text("READY!",165,230);
  }
}
function ghostdots(){
  if (ghostEatStart === 1){
    ghostTimer = ghostTimer + 1;
  }
  if (ghostTimer > 0){
    ghostEat = 1;
  } else {
    ghostEat = 0;
  }
  
  if (ghostTimer > 200){
    ghostTimer = 0;
    ghostEatStart = 0;
    ghostTally = 0;
    BlinkyAlive = 0;
    InkyAlive = 0;
    PinkyAlive = 0;
    ClydeAlive = 0;
  }
  if (ghostEat === 1 && BlinkyAlive === 1){
    Blinky.setAnimation("Blue");
  }
  if (ghostEat === 1 && InkyAlive === 1){
    Inky.setAnimation("Blue");
  }
  if (ghostEat === 1 && PinkyAlive === 1){  
    Pinky.setAnimation("Blue");
  }
  if (ghostEat === 1 && ClydeAlive === 1){
    Clyde.setAnimation("Blue");
  }
  }

function eatingGhosts(){
  if (ghostEat === 1){
    if (Pac.isTouching(Blinky) && BlinkyAlive === 1){
      ghostTally = ghostTally + 1;
      BlinkyAlive = 0;
      Blinky.velocityY = 0;
      Blinky.velocityX = 0;
      blinkyMove = 0;
      Blinky.x = 188;
      Blinky.y = 168;
      timer1 = 0;
      playSound("assets/Ghost.mp3");
      if (ghostTally === 1){
      score = score + 200;
      }
      if (ghostTally === 2){
      score = score + 400;
      }
      if (ghostTally === 3){
      score = score + 600;
      }
      if (ghostTally === 4){
      score = score + 1000;
      lives = lives + 1;
      playSound("assets/Extra.mp3");
      }
    }
     if (Pac.isTouching(Pinky) && PinkyAlive === 1){
      ghostTally = ghostTally + 1;
      PinkyAlive = 0;
      Pinky.velocityY = 0;
      Pinky.velocityX = 0;
      pinkyMove = 0;
      Pinky.x = 210;
      Pinky.y = 188;
      timer3 = 0;
      playSound("assets/Ghost.mp3");
      if (ghostTally === 1){
      score = score + 200;
      }
      if (ghostTally === 2){
      score = score + 400;
      }
      if (ghostTally === 3){
      score = score + 600;
      }
      if (ghostTally === 4){
      score = score + 1000;
      lives = lives + 1;
      playSound("assets/Extra.mp3");
      }
    }
     if (Pac.isTouching(Inky) && InkyAlive === 1){
      ghostTally = ghostTally + 1;
      InkyAlive = 0;
      Inky.velocityY = 0;
      Inky.velocityX = 0;
      inkyMove = 0;
      Inky.x = 210;
      Inky.y = 168;
      timer2 = 0;
      playSound("assets/Ghost.mp3");
      if (ghostTally === 1){
      score = score + 200;
      }
      if (ghostTally === 2){
      score = score + 400;
      }
      if (ghostTally === 3){
      score = score + 600;
      }
      if (ghostTally === 4){
      score = score + 1000;
      lives = lives + 1;
      playSound("assets/Extra.mp3");
      }
    }
     if (Pac.isTouching(Clyde) && ClydeAlive === 1){
      ghostTally = ghostTally + 1;
      ClydeAlive = 0;
      Clyde.velocityY = 0;
      Clyde.velocityX = 0;
      clydeMove = 0;
      Clyde.x = 188;
      Clyde.y = 168;
      timer4 = 0;
      playSound("assets/Ghost.mp3");
      if (ghostTally === 1){
      score = score + 200;
      }
      if (ghostTally === 2){
      score = score + 400;
      }
      if (ghostTally === 3){
      score = score + 600;
      }
      if (ghostTally === 4){
      score = score + 1000;
      lives = lives + 1;
      playSound("assets/Extra.mp3");
      }
    }
  }
}
function cherry1(){
  berryTimer1 = berryTimer1 + 1;
  if (berryTimer1 > randomNumber(300,500) && cherrycheck === 0){
    cherry.x = 200;
    cherry.y = 225;
  }
  if (Pac.isTouching(cherry)){
    playSound("assets/Fruit.mp3");
    cherryEat = 1;
    cherrycheck = 1;
    cherry.x = 225;
    cherry.y = 385;
    score = score + 100;
  }
}
function strawberry1(){
  berryTimer2 = berryTimer2 + 1;
  if (berryTimer2 > randomNumber(1000,1200) && cherryEat === 1 && strawcheck === 0){
    straw.x = 200;
    straw.y = 225;
  }
  if (Pac.isTouching(straw)){
    playSound("assets/Fruit.mp3");
    strawEat = 1;
    strawcheck = 1;
    straw.x = 250;
    straw.y = 385;
    score = score + 150;
  }
}
function orange1(){
  berryTimer3 = berryTimer3 + 1;
  if (berryTimer3 > randomNumber(2000,2200) && strawEat === 1 && orangecheck === 0){
    orange.x = 200;
    orange.y = 225;
  }
  if (Pac.isTouching(orange)){
    playSound("assets/Fruit.mp3");
    orangeEat = 1;
    orangecheck = 1;
    orange.x = 275;
    orange.y = 385;
    score = score + 200;
  }
}
function apple1(){
  berryTimer4 = berryTimer4 + 1;
  if (berryTimer4 > randomNumber(3000,3500) && orangeEat === 1 && applecheck === 0){
    apple.x = 200;
    apple.y = 225;
  }
  if (Pac.isTouching(apple)){
    playSound("assets/Fruit.mp3");
    appleEat = 1;
    applecheck = 1;
    apple.x = 300;
    apple.y = 385;
    score = score + 300;
  }
}
function melon1(){
  berryTimer5 = berryTimer5 + 1;
  if (berryTimer5 > randomNumber(4000,4500) && appleEat === 1 && meloncheck === 0){
    melon.x = 200;
    melon.y = 225;
  }
  if (Pac.isTouching(melon)){
    playSound("assets/Fruit.mp3");
    meloncheck = 1;
    melon.x = 325;
    melon.y = 385;
    score = score + 500;
  }
}
function win(){
  if (dotCount === 182 && winset === 1){
    winset = 0;
    camera.y = 600;
    Blinky.velocityY = 0;
    Blinky.velocityX = 0;
    Blinky.x = 100;
    Blinky.y = 600;
    Inky.velocityY = 0;
    Inky.velocityX = 0;
    Inky.x = 75;
    Inky.y = 600;
    Pinky.velocityY = 0;
    Pinky.velocityX = 0;
    Pinky.x = 50;
    Pinky.y = 600;
    Clyde.velocityY = 0;
    Clyde.velocityX = 0;
    Clyde.x = 25;
    Clyde.y = 600;
    
  }
  if (dotCount === 182){
    fill("yellow");
    textFont("Courier New");
    text("YOU WIN!",150,500);
    fill("white");
    text("SCORE: " + score,140,725);
    if (winPac.x > 370){
      winDirection = 1;
    }
    if (Clyde.x < 15){
      winDirection = 0;
    }
    if (winDirection === 0){
      Blinky.velocityX = 2;
      Inky.velocityX = 2;
      Pinky.velocityX = 2;
      Clyde.velocityX = 2;
      winPac.velocityX = 2;
      Blinky.setAnimation("R_Blinky");
      Inky.setAnimation("R_Inky");
      Pinky.setAnimation("R_Pinky");
      Clyde.setAnimation("R_Clyde");
      winPac.setAnimation("R_Pac");
      winDot.setAnimation("circle");
    }
    if (winDirection === 1){
      Blinky.velocityX = -2;
      Inky.velocityX = -2;
      Pinky.velocityX = -2;
      Clyde.velocityX = -2;
      winPac.velocityX = -2;
      Blinky.setAnimation("Blue");
      Inky.setAnimation("Blue");
      Pinky.setAnimation("Blue");
      Clyde.setAnimation("Blue");
      winPac.setAnimation("L_Pac");
      winDot.setAnimation("black");
    }
  }
}
camera.off();

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
